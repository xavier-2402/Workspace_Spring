package com.ista.springboot.vcard.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootVcardApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootVcardApplication.class, args);
	}

}
